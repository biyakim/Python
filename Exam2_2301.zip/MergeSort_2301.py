# 2301 김비야

f = input("첫 번째 그룹의 데이타 : ")
s = input("두 번째 그룹의 데이타 : ")
add = f+" "+s
answer = add.split(" ")
answer.sort()
print("병합된 그룹의 데이타 :",answer)