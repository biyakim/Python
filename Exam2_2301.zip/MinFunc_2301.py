#2301 김비야

def min_in_list():
    num = int(input("수 입력하세요"))
    num_list = []
    while(num != 0):
        num_list.append(num)

    print("입력데이타 : ",num_list)
    min = num_list[0]
    for i in range(len(num_list)):
        if min > num_list[i]:
            min = num_list
    print(min)

    
